from setuptools import setup

setup(name='gw_probability',
      version='0.2',
      description='Gaussian and Binomial distributions',
      packages=['gw_probability'],
      author='George Wee',
      zip_safe=False)
